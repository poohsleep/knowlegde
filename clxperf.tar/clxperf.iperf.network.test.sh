#!/bin/bash

#############

USAGE="usage: $0

Usage:
    Performs a smoke test of the network of a cluster.  The test produces graphical
    results which demonstate balance across the cluster.  A healthly cluster would produce similar
    performance curves for each node in the cluster.
    
    The test by default will do a full network test ( n to n ).  Optionally you can 
    include a point to point test ( n to 1 ).
    
Optional Arguments:
    point2point, --point2point point to point network test

    host, --host              host name of a node of the cluster (default: localhost)
    user, --user              host user (default: current userid)
    port, --port              host port number
    pem, --pem                pem file 
    
    dbuser, --dbuser          database user name (default: root)
    dbport, --dbport          mysql port number (default: 3306)
    dbpassword, --dbpassword  database user password
    
    duration, --duration      length of each test point in seconds (default: 10)
    
    nocompress                disable compression of result directory

    help, --help              show usage message and exits
     
Notes:
1.  The script can be run either 'on-platform' or 'off-platform' depending on connectivity and 
access to the cluster.

Here are some options.

1a.  Use a pem file.
     (This method assumes that the userid can access all nodes in the cluster using the pem file.)

    ./clxperf.iperf.network.test.sh --host node --user userid --pem ~/.ssh/somepemfile.pem

1d.  Execute the script from a remote node, providing connection info to the cluster.
     (This method assumes that user has passwordless ssh access to all nodes in the cluster.)

    ./clxperf.iperf.network.test.sh --host node --user userid

1c.  Copy the script onto a node in the cluster, execute the script on that node, then copy the
     results off.
     (This method assumes the userid can do remote logins from the host node to all the other
     nodes in the cluster.)
     
     scp clxperf.sysbench.cpu.test.sh userid@node:.
     ssh userid@node './clxperf.iperf.network.test.sh'
     scp userid@node:*.clxperf.*.tgz .
     ssh userid@node 'rm -rf *.clxperf.*'

1d.  Pipe the script through an ssh logon to a node in the cluster.  The results will be on
     the cluster node an will need to be copied off.

    ssh userid@node < clxperf.iperf.network.test.sh
    scp userid@node:*.clxperf.*.tgz .
    ssh userid@node 'rm -rf *.clxperf.*'

2.  The script will install iperf, gnuplot, and liberation-sans-fonts on each node of 
the cluster.
"

while [[ $# > 0 ]] ; do
    key="$1"; shift;
    case ${key} in
        point2point|--point2point)  OPTION_POINT_2_POINT="TRUE";;
        host|--host)                HOST="$1"; shift;;
        user|--user)                USERID="$1"; shift;;
        password|--password)        PASSWORD="$1"; shift;;
        port|--port)                PORT="$1"; shift;;
        pem|--pem)                  PEM="$1"; shift;;
        dbuser|--dbuser)            DBUSER="$1"; shift;;
        dbport|--dbport)            DBPORT="$1"; shift;;
        dbpassword|--dbpassword)    DBPASSWORD="$1"; shift;;
        duration|--duration)        DURATION="$1"; shift;;
        nocompress)                 OPTION_COMPRESS=FALSE;;
        help|--help)                echo -e "$USAGE"; exit 1;;
        *)                          echo "Invalid option specified : $key"; echo -e "$USAGE"; exit 1;;
    esac
done

# Defaults
if [[ ! ${HOST} ]] ;            then HOST=localhost;       fi
if [[ ! ${USERID} ]] ;          then USERID=$(whoami);     fi
if [[ ! ${DBUSER} ]] ;          then DBUSER=root;          fi
if [[ ! ${DBPORT} ]] ;          then DBPORT=3306;          fi
if [[ ! ${DURATION} ]] ;        then DURATION=10;          fi
if [[ ! ${OPTION_COMPRESS} ]] ; then OPTION_COMPRESS=TRUE; fi

if [[ ${PORT} ]] ; then
    PORT_OPTION="-p${PORT}"
fi
if [[ ${PEM} ]] ; then
    PEM_OPTION="-i${PEM}"
fi
SSH_OPTIONS="-oStrictHostKeyChecking=no ${SSH_PORT_OPTION} ${PEM_OPTION}"

if [[ ${DBUSER} ]] ; then
    DBUSER_OPTION="--user=${DBUSER}"
fi
if [[ ${DBPORT} ]] ; then
    DBPORT_OPTION="--port=${DBPORT}"
fi
if [[ ${DBPASSWORD} ]] ; then
    DBPASSWORD_OPTION="--password=${DBPASSWORD}"
fi
MYSQL_OPTIONS="${DBUSER_OPTION} ${DBPORT_OPTION} ${DBPASSWORD_OPTION}"

BLOCK_SIZES="512 8k 128k"

#############

# get the cluster name
COMMAND="mysql -sN ${MYSQL_OPTIONS} -e\"show variables like 'cluster_name'\""
CLUSTER_NAME=$( ssh ${USERID}@${HOST} ${SSH_OPTIONS} "${COMMAND}" | awk '{print $2}' )

# create a new work directory
TESTID=$(date +%y%m%d.%H%M%S).${CLUSTER_NAME}
if [[ ${LOGDIRECTORY} ]] ; then
    WORKDIRECTORY=${LOGDIRECTORY}/${TESTID}.clxperf.iperf.network.test
else
    WORKDIRECTORY=${TESTID}.clxperf.iperf.network.test
fi
mkdir -p ${WORKDIRECTORY}
mkdir -p ${WORKDIRECTORY}/log

{
    echo ""
    echo "    ===== Begin clxperf.iperf.network.test.sh =====  [ $(date -u '+%Y-%m-%d %H:%M:%S') ]"
    
    STARTSECONDS=$SECONDS
    
    echo ""
    echo "        Cluster Name : $CLUSTER_NAME"
    
    # Determine the nodes
    COMMAND="mysql -sN ${MYSQL_OPTIONS} -e\"select iface_ip from system.nodeinfo order by 1\""
    CLUSTER_NODES=$( ssh ${USERID}@${HOST} ${SSH_OPTIONS} "${COMMAND}" | awk '{printf "%s ", $1}')
    echo ""
    echo "        Cluster Nodes : ${CLUSTER_NODES[*]}"
    
    # Install iperf on each node
    echo ""
    echo "    ===== Node Setup : Installing iperf =====  [ $(date -u '+%Y-%m-%d %H:%M:%S') ]"
    time {
        for NODE in ${CLUSTER_NODES[*]} ; do
            {
                echo "Node : ${NODE}"
                ssh ${USERID}@${NODE} ${SSH_OPTIONS} 'sudo yum -y install epel-release; sudo yum -y install iperf; sudo yum -y install gnuplot; sudo yum -y install liberation-sans-fonts;'
                ssh ${USERID}@${NODE} ${SSH_OPTIONS} 'iperf --version'
            } > ${WORKDIRECTORY}/log/${NODE}.setup.log 2>&1 &
        done
        wait
    }

    if [[ ${OPTION_POINT_2_POINT} ]] ; then
        
        echo ""
        echo "    ===== Network Test - Point to Point =====  [ $(date -u '+%Y-%m-%d %H:%M:%S') ]"
        time {
            #  Run a test with each node as a server and the rest of the nodes as clients driving the server
            for NETWORK in iface_ip be_ip ; do
                echo ""
                echo "        Network Interface : ${NETWORK}    "
                echo -e 'to_node''\t''Mbits_sec''\t''uom' > ${WORKDIRECTORY}/${NETWORK}.send.data.txt
                echo -e 'to_node''\t''Mbits_sec''\t''uom' > ${WORKDIRECTORY}/${NETWORK}.receive.data.txt
                for SERVER_NODE in ${CLUSTER_NODES[*]} ; do
                    echo ""
                    echo "            Server Node : ${SERVER_NODE}    "
                    
                    # Get IP ADDRESS
                    COMMAND="mysql -sN ${MYSQL_OPTIONS} -e\"select ${NETWORK} from system.nodeinfo where iface_ip = '${SERVER_NODE}'\""
                    SERVERIPADDRESS=$( ssh ${USERID}@${HOST} ${SSH_OPTIONS} "${COMMAND}" )
                    
                    echo "                Server IP Address : ${SERVERIPADDRESS}"
                    echo "                Starting ${SERVER_NODE} Server process"
                    ssh ${USERID}@${SERVER_NODE} ${SSH_OPTIONS} 'iperf -s -l 128k' > ${WORKDIRECTORY}/log/${NETWORK}.${SERVER_NODE}.server.receive.log 2>&1 &
                    sleep 0.1
                    echo "                Starting Client processes on each node"
                    for CLIENT_NODE in ${CLUSTER_NODES[*]} ; do
                        if [[ ${CLIENT_NODE} != ${SERVER_NODE} ]] ; then
                            
                            COMMAND="mysql -sN ${MYSQL_OPTIONS} -e\"select ${NETWORK} from system.nodeinfo where iface_ip = '${CLIENT_NODE}'\""
                            CLIENTIPADDRESS=$( ssh ${USERID}@${HOST} ${SSH_OPTIONS} "${COMMAND}" )
                            echo "                    Client : ${CLIENTIPADDRESS} to ${SERVERIPADDRESS}"
                            ssh ${USERID}@${CLIENT_NODE} ${SSH_OPTIONS} "iperf -c ${SERVERIPADDRESS} -l 128k -t 10000" > ${WORKDIRECTORY}/log/${NETWORK}.${CLIENT_NODE}.to.${SERVER_NODE}.client.send.log 2>&1 &
                        fi
                    done
                    echo "                Sleep $(( ${DURATION} )) seconds to allow test to finish"
                    sleep ${DURATION}
                    echo "                Node Clean up"
                    for NODE in ${CLUSTER_NODES[*]} ; do
                        ssh ${USERID}@${NODE} ${SSH_OPTIONS} 'killall iperf' 2>/dev/null 
                    done
                    
                    echo "                Check for connection refusals : "
                    grep 'refused' ${WORKDIRECTORY}/log/${NETWORK}.*.to.${SERVER_NODE}.client.send.log
                    
                    grep ' sec ' ${WORKDIRECTORY}/log/${NETWORK}.*.to.${SERVER_NODE}.client.send.log | awk -v server=${SERVER_NODE} '
                    BEGIN { total = 0 }
                    { if ( $8 == "Mbits/sec" ) { total = total + $7 }; if ( $8 == "Gbits/sec" ) { total = total + $7 * 1000 }; }
                    END { printf "%s\t%s\tMbits/sec\n", server, total }
                    ' >> ${WORKDIRECTORY}/${NETWORK}.send.data.txt
                    grep ' sec ' ${WORKDIRECTORY}/log/${NETWORK}.${SERVER_NODE}.server.receive.log | awk -v server=${SERVER_NODE} '
                    BEGIN { total = 0 }
                    { if ( $8 == "Mbits/sec" ) { total = total + $7 }; if ( $8 == "Gbits/sec" ) { total = total + $7 * 1000 }; }
                    END { printf "%s\t%s\tMbits/sec\n", server, total }
                    '  >> ${WORKDIRECTORY}/${NETWORK}.receive.data.txt
                done
            done
            
            echo ""
            echo "    ===== Test Data - Front End Network =====  [ $(date -u '+%Y-%m-%d %H:%M:%S') ]"
            echo ""
            echo "        Network Send Data :"
            cat ${WORKDIRECTORY}/iface_ip.send.data.txt
            echo ""
            echo "        Network Receive Data :"
            cat ${WORKDIRECTORY}/iface_ip.receive.data.txt
            echo ""
            echo "    ===== Test Data - Back End Network =====  [ $(date -u '+%Y-%m-%d %H:%M:%S') ]"
            echo ""
            echo "        Network Send Data :"
            cat ${WORKDIRECTORY}/be_ip.send.data.txt
            echo ""
            echo "        Network Receive Data :"
            cat ${WORKDIRECTORY}/be_ip.receive.data.txt
            
            for NETWORK in iface_ip be_ip ; do
                {
                    echo "set datafile separator '\t'"
                    echo "set terminal png size 1280,480 enhanced font '/usr/share/fonts/liberation/LiberationSans-Regular.ttf' 11 linewidth 2"
                    echo "set yrange [0:]"
                    echo "set ylabel 'Throughput from Allnodes to Node'"
                    echo "set xlabel 'To Node'"
                    echo "set output '${WORKDIRECTORY}/${NETWORK}.send.data.png'"
                    echo "set title 'Network Send Throughput'"
                    echo "set style data histogram"
                    echo "set style fill solid border"
                    echo "set key autotitle columnheader"
                    echo "plot '${WORKDIRECTORY}/${NETWORK}.send.data.txt' using 2:xticlabel(1)"
                    echo "exit"
                } | gnuplot > ${WORKDIRECTORY}/log/gnuplot.send.log 2>&1
                {
                    echo "set datafile separator '\t'"
                    echo "set terminal png size 1280,480 enhanced font '/usr/share/fonts/liberation/LiberationSans-Regular.ttf' 11 linewidth 2"
                    echo "set yrange [0:]"
                    echo "set ylabel 'Throughput from Allnodes to Node'"
                    echo "set xlabel 'To Node'"
                    echo "set output '${WORKDIRECTORY}/${NETWORK}.receive.data.png'"
                    echo "set title 'Network Receive Throughput'"
                    echo "set style data histogram"
                    echo "set style fill solid border"
                    echo "set key autotitle columnheader"
                    echo "plot '${WORKDIRECTORY}/${NETWORK}.receive.data.txt' using 2:xticlabel(1)"
                    echo "exit"
                } | gnuplot > ${WORKDIRECTORY}/log/gnuplot.receive.log 2>&1
            done
        
        }
    fi

    echo ""
    echo "    ===== Network Test - Full Network =====  [ $(date -u '+%Y-%m-%d %H:%M:%S') ]"
    time {
        for NETWORK in iface_ip be_ip ; do
            echo ""
            echo "        Network Interface : ${NETWORK}    "
            for BLOCK_SIZE in ${BLOCK_SIZES} ; do
                echo ""
                echo "        Block Size : ${BLOCK_SIZE}    "
            #  Full Network Test
                echo -e 'Operation''\t''Mbits_sec''\t''uom' > ${WORKDIRECTORY}/${NETWORK}.${BLOCK_SIZE}.full.data.txt
                COMMAND="mysql -sN ${MYSQL_OPTIONS} -e\"select iface_ip from system.nodeinfo order by iface_ip\""
                HOSTIPS=( $( ssh ${USERID}@${HOST} ${SSH_OPTIONS} "${COMMAND}" ) )
                COMMAND="mysql -sN ${MYSQL_OPTIONS} -e\"select ${NETWORK} from system.nodeinfo order by iface_ip\""
                IPADDRESSES=( $( ssh ${USERID}@${HOST} ${SSH_OPTIONS} "${COMMAND}" ) )
                #  Start the servers
                SERVER_IDX=0
                printf "            Starting Server Processes "
                while (( ${SERVER_IDX} < ${#HOSTIPS[@]} )) ; do
                    SERVER_NODE=${HOSTIPS[${SERVER_IDX}]}
                    sleep 0.01
                    # echo "            Server Node : ${SERVER_NODE} - Starting Server Process"
                    printf "."
                    ssh ${USERID}@${SERVER_NODE} ${SSH_OPTIONS} "iperf -s -l ${BLOCK_SIZE} --format=m" > ${WORKDIRECTORY}/log/${NETWORK}.${BLOCK_SIZE}.full.${SERVER_NODE}.server.receive.log 2>&1 &
                    (( SERVER_IDX = ${SERVER_IDX} + 1 ))
                done
                printf "\n"
                SERVER_IDX=0
                printf "            Starting Client Processes "
                while (( ${SERVER_IDX} < ${#HOSTIPS[@]} )) ; do
                    SERVER_NODE=${HOSTIPS[${SERVER_IDX}]}
                    # Get IP ADDRESS
                    SERVERIPADDRESS=${IPADDRESSES[${SERVER_IDX}]}
                    #printf "            Server Node : ${SERVER_NODE} - Server IP Address : ${SERVERIPADDRESS} - Starting Client Processes "
                    # Start the clients
                    CLIENT_IDX=0
                    while (( ${CLIENT_IDX} < ${#HOSTIPS[@]} )) ; do
                        CLIENT_NODE=${HOSTIPS[${CLIENT_IDX}]}
                        if [[ ${CLIENT_IDX} != ${SERVER_IDX} ]] ; then
                            CLIENTIPADDRESS=${IPADDRESSES[${CLIENT_IDX}]}
                            sleep 0.01
                            printf "."
                            # echo "                    Client : ${CLIENTIPADDRESS} to ${SERVERIPADDRESS}"
                            ssh ${USERID}@${CLIENT_NODE} ${SSH_OPTIONS} "iperf -c ${SERVERIPADDRESS} -l ${BLOCK_SIZE} -t ${DURATION} --format=m" > ${WORKDIRECTORY}/log/${NETWORK}.${BLOCK_SIZE}.full.${CLIENT_NODE}.to.${SERVER_NODE}.client.send.log 2>&1 &
                        fi
                        (( CLIENT_IDX = ${CLIENT_IDX} + 1 ))
                    done
                    (( SERVER_IDX = ${SERVER_IDX} + 1 ))
                done
                printf "\n"
                        
                echo "            Sleep $(( ${DURATION} )) seconds to allow test to finish"
                sleep ${DURATION}
            
                echo "            Node Clean up"
                for NODE in ${CLUSTER_NODES[*]} ; do
                    ssh ${USERID}@${NODE} ${SSH_OPTIONS} 'killall iperf' 2>/dev/null 
                done
                echo "            Check for connection refusals : "
                grep 'refused' ${WORKDIRECTORY}/log/${NETWORK}.${BLOCK_SIZE}.full.*.to.*.client.send.log
                
                cat ${WORKDIRECTORY}/log/${NETWORK}.${BLOCK_SIZE}.full.*.to.*.client.send.log | grep ' sec ' | awk '
                    BEGIN { total = 0 }
                    { if ( $8 == "Mbits/sec" ) { total = total + $7 }; if ( $8 == "Gbits/sec" ) { total = total + $7 * 1000 }; }
                    END { printf "Send\t%s\tMbits/sec\n", total }
                    ' >> ${WORKDIRECTORY}/${NETWORK}.${BLOCK_SIZE}.full.data.txt
                cat ${WORKDIRECTORY}/log/${NETWORK}.${BLOCK_SIZE}.full.*.server.receive.log | grep ' sec ' | awk '
                    BEGIN { total = 0 }
                    { if ( $8 == "Mbits/sec" ) { total = total + $7 }; if ( $8 == "Gbits/sec" ) { total = total + $7 * 1000 }; }
                    END { printf "Receive\t%s\tMbits/sec\n", total }
                    '  >> ${WORKDIRECTORY}/${NETWORK}.${BLOCK_SIZE}.full.data.txt
                
                echo ""
                echo "    ===== Test Data - Network Interface : ${NETWORK} =====  [ $(date -u '+%Y-%m-%d %H:%M:%S') ]"
                echo ""
                echo "        Network Data :"
                cat ${WORKDIRECTORY}/${NETWORK}.${BLOCK_SIZE}.full.data.txt
                
                POWER_RATING=$(cat ${WORKDIRECTORY}/${NETWORK}.${BLOCK_SIZE}.full.data.txt | (read; cat) | cut -f2 | awk 'BEGIN { tot = 0; count = 0; }; {  tot = tot + $1; count = count + 1; }; END { printf "%0.2f", tot/count }')
                echo ""
                echo "    Network ${NETWORK} ${BLOCK_SIZE} Power Rating : ${POWER_RATING}"
                echo "${POWER_RATING}" > ${WORKDIRECTORY}/${NETWORK}.${BLOCK_SIZE}.power.rating.txt
                
            done
        
        		{
			    echo "
			    set datafile separator '\t'
			    set terminal png size 960,480 enhanced font '/usr/share/fonts/liberation/LiberationSans-Regular.ttf' 11 linewidth 2
			    set yrange [0:]
			    set ylabel 'Throughput from Allnodes to Node'
			    set xlabel 'To Node'
			    set output '${WORKDIRECTORY}/${NETWORK}.data.png'
			    set title '${NETWORK} Network Throughput'
			    set style data histogram
			    set style fill solid border
			    set key autotitle columnheader
			    "
			    INDX=0
			    for BLOCK_SIZE in ${BLOCK_SIZES} ; do
			        INDX=$(( ${INDX} + 1 ))
			    if (( ${INDX} == 1 )) ; then
			            echo "plot '${WORKDIRECTORY}/${NETWORK}.${BLOCK_SIZE}.full.data.txt' using 2:xticlabel(1) title '${BLOCK_SIZE} bytes' \\"
			        else
			            echo ", '${WORKDIRECTORY}/${NETWORK}.${BLOCK_SIZE}.full.data.txt' using 2:xticlabel(1) title '${BLOCK_SIZE} bytes' \\"
			        fi
			    done
			    echo ""
			    echo "exit"
			} | gnuplot > ${WORKDIRECTORY}/log/gnuplot.log 2>&1
        
        done
    
    }
    
    {
        echo '<html>'
        echo '<body>'
        echo '<h1>Cluster Network Test</h1>'
        echo "<h3>Cluster Name : ${CLUSTER_NAME}</h3>"
        echo "<h3>Cluster Nodes : ${CLUSTER_NODES[*]}</h3>"
        echo '<h2>Full Network Test Results</h2>'
        echo '<h3>Front End Network</h3>'
        echo '<img src="iface_ip.data.png" />'
        echo '<h3>Back End Network</h3>'
        echo '<img src="be_ip.data.png" />'
        echo "<h3>Front End Results by Block Size:</h3>"
        for BLOCK_SIZE in ${BLOCK_SIZES} ; do
            echo "<h4>Block Size : ${BLOCK_SIZE}</h4>"
            echo "Power Rating : $(cat ${WORKDIRECTORY}/iface_ip.${BLOCK_SIZE}.power.rating.txt)"
            echo '<pre>'
            cat ${WORKDIRECTORY}/iface_ip.${BLOCK_SIZE}.full.data.txt
            echo '</pre>'
        done
        echo "<h3>Back End Results by Block Size:</h3>"
        for BLOCK_SIZE in ${BLOCK_SIZES} ; do
            echo "<h4>Block Size : ${BLOCK_SIZE}</h4>"
            echo "Power Rating : $(cat ${WORKDIRECTORY}/be_ip.${BLOCK_SIZE}.power.rating.txt)"
            echo '<pre>'
            cat ${WORKDIRECTORY}/be_ip.${BLOCK_SIZE}.full.data.txt
            echo '</pre>'
        done
        if [[ ${OPTION_POINT_2_POINT} ]] ; then
            echo '<h2>Point to Point Test Results</h2>'
            echo '<h3>Front End Network Send Data</h3>'
            echo '<img src="iface_ip.send.data.png" />'
            echo '<pre>'
            cat ${WORKDIRECTORY}/iface_ip.send.data.txt
            echo '</pre>'
            echo '<h3>Front End Network Receive Data</h3>'
            echo '<img src="iface_ip.receive.data.png" />'
            echo '<pre>'
            cat ${WORKDIRECTORY}/iface_ip.receive.data.txt
            echo '</pre>'
            echo '<h3>Back End Network Send Data</h3>'
            echo '<img src="be_ip.send.data.png" />'
            echo '<pre>'
            cat ${WORKDIRECTORY}/be_ip.send.data.txt
            echo '</pre>'
            echo '<h3>Back End Network Receive Data</h3>'
            echo '<img src="be_ip.receive.data.png" />'
            echo '<pre>'
            cat ${WORKDIRECTORY}/be_ip.receive.data.txt
            echo '</pre>'
        fi
        echo '<h2>Test Files</h2>'
        for FILE in $(ls -1 ${WORKDIRECTORY}/ | awk -F'/' '{print $(NF)}' ) ; do
            echo $FILE |  awk '{ printf "<h4><a href=\"%s\">%s</a></h4>\n", $1, $1 ; }'
        done
    } > ${WORKDIRECTORY}/index.html
    
    echo ""
    echo "    ===== Test complete =====  [ $(date -u '+%Y-%m-%d %H:%M:%S') ]"
    echo ""
    if [[ ${OPTION_COMPRESS} == TRUE ]] ; then
        echo "        Results File : ${WORKDIRECTORY}.tgz"
        echo ""
    fi
    echo "    ===== End clxperf.iperf.network.test.sh ( Elapsed Seconds = $(( $SECONDS - $STARTSECONDS )) ) =====  [ $(date -u '+%Y-%m-%d %H:%M:%S') ]"
    echo ""
    
} 2>&1 | tee ${WORKDIRECTORY}/log/clxperf.iperf.network.test.log
    
# zip it all up
if [[ ${OPTION_COMPRESS} == TRUE ]] ; then
    if [[ ${LOGDIRECTORY} ]] ; then
        cd ${LOGDIRECTORY}; tar czf ${WORKDIRECTORY}.tgz ${TESTID}*/
    else
        tar czf ${WORKDIRECTORY}.tgz ${TESTID}*/
    fi
fi
