#!/bin/bash

#############

USAGE="usage: $0

Usage:
    Performs a smoke test of the database installation on a cluster.  The test produces graphical
    results which demonstate balance across the cluster.  A healthly cluster would produce similar
    performance curves for each node in the cluster.
    
Optional Arguments:
    host, --host              host name of a node of the cluster (default: localhost)
    user, --user              host user (default: current userid)
    port, --port              host port number
    pem, --pem                pem file 
        
    dbuser, --dbuser          database user name (default: root)
    dbport, --dbport          mysql port number (default: 3306)
    dbpassword, --dbpassword  database user password
    
    duration, --duration      length of each test point in seconds (default: 10)
    tablesize, --tablesize    number of records in the test table (default: 8388608)
    maxthreads, --maxthreads  maximum number of threads to run (default: 4096)
    
    growth, --growth          method of growth in threads (default: quadratic)
                                valid values: linear (base*n), exponential (base^n), quadratic (n^base)
    basevalue, --basevalue    base value in growth (default: 2)
    
    nocompress                disable compression of result directory

    help, --help              show usage message and exits
     
Notes:
1.  The script can be run either 'on-platform' or 'off-platform' depending on connectivity and 
access to the cluster.

Here are some options.

1a.  Use a pem file.
     (This method assumes that the userid can access all nodes in the cluster using the pem file.)

    ./clxperf.sysbench.db.test.sh --host node --user userid --pem ~/.ssh/somepemfile.pem

1d.  Execute the script from a remote node, providing connection info to the cluster.
     (This method assumes that user has passwordless ssh access to all nodes in the cluster.)

    ./clxperf.sysbench.db.test.sh --host node --user userid

1c.  Copy the script onto a node in the cluster, execute the script on that node, then copy the
     results off.
     (This method assumes the userid can do remote logins from the host node to all the other
     nodes in the cluster.)
     
     scp clxperf.sysbench.cpu.test.sh userid@node:.
     ssh userid@node './clxperf.sysbench.db.test.sh'
     scp userid@node:*.clxperf.*.tgz .
     ssh userid@node 'rm -rf *.clxperf.*'

1d.  Pipe the script through an ssh logon to a node in the cluster.  The results will be on
     the cluster node an will need to be copied off.

    ssh userid@node < clxperf.sysbench.db.test.sh
    scp userid@node:*.clxperf.*.tgz .
    ssh userid@node 'rm -rf *.clxperf.*'

2.  The script will install sysbench, gnuplot, and liberation-sans-fonts on each node of 
the cluster.
"

while [[ $# > 0 ]] ; do
    key="$1"; shift;
    case ${key} in
        host|--host)              HOST="$1"; shift;;
        user|--user)              USERID="$1"; shift;;
        password|--password)      PASSWORD="$1"; shift;;
        port|--port)              PORT="$1"; shift;;
        pem|--pem)                PEM="$1"; shift;;
        dbuser|--dbuser)          DBUSER="$1"; shift;;
        dbport|--dbport)          DBPORT="$1"; shift;;
        dbpassword|--dbpassword)  DBPASSWORD="$1"; shift;;
        duration|--duration)      DURATION="$1"; shift;;
        tablesize|--tablesize)    TABLE_SIZE="$1"; shift;;
        maxthreads|--maxthreads)  MAX_THREADS="$1"; shift;;
        growth|--growth)          GROWTH="$1"; shift;;
        basevalue|--basevalue)    BASEVALUE="$1"; shift;;
        nocompress)               OPTION_COMPRESS=FALSE;;
        help|--help)              echo -e "$USAGE"; exit 1;;
        *)                        echo "Invalid option specified : $key"; echo -e "$USAGE"; exit 1;;
    esac
done

# Defaults
if [[ ! ${HOST} ]] ;            then HOST=localhost;       fi
if [[ ! ${USERID} ]] ;          then USERID=$(whoami);     fi
if [[ ! ${DBUSER} ]] ;          then DBUSER=root;          fi
if [[ ! ${DBPORT} ]] ;          then DBPORT=3306;          fi
if [[ ! ${DURATION} ]] ;        then DURATION=10;          fi
if [[ ! ${TABLE_SIZE} ]] ;      then TABLE_SIZE=8388608;   fi
if [[ ! ${MAX_THREADS} ]] ;     then MAX_THREADS=4096;     fi
if [[ ! ${OPTION_COMPRESS} ]] ; then OPTION_COMPRESS=TRUE; fi

if [[ ${PORT} ]] ; then
    PORT_OPTION="-p${PORT}"
fi
if [[ ${PEM} ]] ; then
    PEM_OPTION="-i${PEM}"
fi
SSH_OPTIONS="-oStrictHostKeyChecking=no ${SSH_PORT_OPTION} ${PEM_OPTION}"

if [[ ${DBUSER} ]] ; then
    DBUSER_OPTION="--user=${DBUSER}"
fi
if [[ ${DBPORT} ]] ; then
    DBPORT_OPTION="--port=${DBPORT}"
fi
if [[ ${DBPASSWORD} ]] ; then
    DBPASSWORD_OPTION="--password=${DBPASSWORD}"
fi
MYSQL_OPTIONS="${DBUSER_OPTION} ${DBPORT_OPTION} ${DBPASSWORD_OPTION}"

if [[ ! ${GROWTH} ]] ; then
    GROWTH=exponential
fi

if [[ ! ${BASEVALUE} ]] ; then
    BASEVALUE=2
fi

if [[ ${GROWTH} == linear ]] ; then N=1;
elif [[ ${GROWTH} == exponential ]] ; then N=1;
elif [[ ${GROWTH} == quadratic ]] ; then N=1;
else
    echo "Invalid growth option specified : ${GROWTH}"; echo -e "$USAGE"; exit 1;
fi

#############

# get the cluster name
COMMAND="mysql -sN ${MYSQL_OPTIONS} -e\"show variables like 'cluster_name'\""
CLUSTER_NAME=$( ssh ${USERID}@${HOST} ${SSH_OPTIONS} "${COMMAND}" | awk '{print $2}' )

# create a new work directory
TESTID=$(date +%y%m%d.%H%M%S).${CLUSTER_NAME}
if [[ ${LOGDIRECTORY} ]] ; then
    WORKDIRECTORY=${LOGDIRECTORY}/${TESTID}.clxperf.sysbench.db.test
else
    WORKDIRECTORY=${TESTID}.clxperf.sysbench.db.test
fi
mkdir -p ${WORKDIRECTORY}
mkdir -p ${WORKDIRECTORY}/log

{
    echo ""
    echo "    ===== Begin clxperf.sysbench.db.test.sh =====  [ $(date -u '+%Y-%m-%d %H:%M:%S') ]"
    
    STARTSECONDS=$SECONDS
    
    echo ""
    echo "        Cluster Name : $CLUSTER_NAME"
    
    # Determine the nodes
    COMMAND="mysql -sN ${MYSQL_OPTIONS} -e\"select iface_ip from system.nodeinfo order by 1\""
    CLUSTER_NODES=$( ssh ${USERID}@${HOST} ${SSH_OPTIONS} "${COMMAND}" | awk '{printf "%s ", $1}')
    echo ""
    echo "        Cluster Nodes : ${CLUSTER_NODES[*]}"
    
    # Install latest version of sysbench 1.0 on each node
    echo ""
    echo "    ===== Node Setup : Installing sysbench =====  [ $(date -u '+%Y-%m-%d %H:%M:%S') ]"
    time {
        for NODE in ${CLUSTER_NODES[*]} ; do
            {
                echo "Node : ${NODE}"
                ssh ${USERID}@${NODE} ${SSH_OPTIONS} 'sudo curl -s https://packagecloud.io/install/repositories/akopytov/sysbench/script.rpm.sh | sudo bash'
                ssh ${USERID}@${NODE} ${SSH_OPTIONS} 'sudo yum -y install sysbench; sudo yum -y install gnuplot; sudo yum -y install liberation-sans-fonts;'
                ssh ${USERID}@${NODE} ${SSH_OPTIONS} 'sysbench --version'
            } > ${WORKDIRECTORY}/log/${NODE}.setup.log 2>&1 &
        done
        wait
    }
    
    echo ""
    echo "    ===== Check/Load Data =====  [ $(date -u '+%Y-%m-%d %H:%M:%S') ]"
    time {
        COMMAND="mysql -sN ${MYSQL_OPTIONS} -e\"select count(*) from clustrix_perf.sbtest1\""
        DATABASE_RECORDS=$( ssh ${USERID}@${HOST} ${SSH_OPTIONS} "${COMMAND}" )
        if [[ ${DATABASE_RECORDS} != "${TABLE_SIZE}" ]] ; then
            
            echo "        Loading ${TABLE_SIZE} records into clustrix_perf.sbtest"
            
            COMMAND="mysql -vvv ${MYSQL_OPTIONS} -e\"set autocommit=true; create database if not exists clustrix_perf; drop table if exists clustrix_perf.sbtest1;\""
            ssh ${USERID}@${HOST} ${SSH_OPTIONS} "${COMMAND}"
            
            SEED_SIZE=$(echo "${TABLE_SIZE} 16" | awk '{ print $1/$2 }')
            COMMAND="sysbench oltp_point_select --mysql-db=clustrix_perf --threads=128 --db-driver=mysql --mysql-host=localhost --mysql-port=${DBPORT} --mysql-user=${DBUSER} --mysql-password=${DBPASSWORD} --table-size=${SEED_SIZE} prepare"
            ssh ${USERID}@${HOST} ${SSH_OPTIONS} "${COMMAND}"
                        
            COMMAND="mysql -sN ${MYSQL_OPTIONS} -e\"select @@lock_on_insert_select\""
            CURRENT_LOCK_ON_INSERT_SELECT=$( ssh ${USERID}@${HOST} ${SSH_OPTIONS} "${COMMAND}" )
            echo "         Current lock_on_insert_select : ${CURRENT_LOCK_ON_INSERT_SELECT}"

            COMMAND="mysql -vvv ${MYSQL_OPTIONS} -e\"set autocommit=true;
            set global lock_on_insert_select=false;
            insert into clustrix_perf.sbtest1 (k , c, pad) select k, c, pad from clustrix_perf.sbtest1;
            insert into clustrix_perf.sbtest1 (k , c, pad) select k, c, pad from clustrix_perf.sbtest1;
            insert into clustrix_perf.sbtest1 (k , c, pad) select k, c, pad from clustrix_perf.sbtest1;
            insert into clustrix_perf.sbtest1 (k , c, pad) select k, c, pad from clustrix_perf.sbtest1;
            show create table clustrix_perf.sbtest1;
            select count(*) from clustrix_perf.sbtest1;
            set global lock_on_insert_select=${CURRENT_LOCK_ON_INSERT_SELECT};
            \""
            ssh ${USERID}@${HOST} ${SSH_OPTIONS} "${COMMAND}"
        else
            echo "        Table clustrix_perf.sbtest already loaded with ${TABLE_SIZE} records"
        fi
    } > ${WORKDIRECTORY}/log/check.load.data.log 2>&1
    
    echo ""
    echo "    ===== Database Test =====  [ $(date -u '+%Y-%m-%d %H:%M:%S') ]"
    for SYSBENCH_TEST in reads 9010 writes ; do
        
        if [[ ${SYSBENCH_TEST} == reads ]] ; then
            TARGETLATENCY=5.0
            SYSBENCH_WORKLOAD="oltp_read_write --point-selects=1 --range_selects=false --index_updates=0 --non-index_updates=0 --delete_inserts=0 --skip-trx=on"
        elif [[ ${SYSBENCH_TEST} == 9010 ]] ; then
            TARGETLATENCY=50.0
            SYSBENCH_WORKLOAD="oltp_read_write --point-selects=9 --range-selects=false --index-updates=0 --non-index-updates=1 --delete-inserts=0"
        else # SYSBENCH_TEST=write
            TARGETLATENCY=20.0
            SYSBENCH_WORKLOAD="oltp_read_write --point-selects=0 --range_selects=false --index_updates=0 --non-index_updates=1 --delete_inserts=0 --skip-trx=on"
        fi
        
        echo ""
        echo "        ===== Sysbench Test : ${SYSBENCH_TEST} =====  [ $(date -u '+%Y-%m-%d %H:%M:%S') ]"
        time {
            
            for NODE in ${CLUSTER_NODES[*]} ; do
                echo -e 'threads''\t''ops''\t''avg_latency''\t''95_percentile' > ${WORKDIRECTORY}/${NODE}.sysbench.${SYSBENCH_TEST}.data.txt
            done
            
            THREADS=1;
            CURRENT_LATENCY=0.0
            while (( $(echo "${CURRENT_LATENCY} ${TARGETLATENCY}" | awk '{print ($1 < $2)}') && (( $THREADS <= ${MAX_THREADS} )) )); do
                
                COMMAND="sysbench ${SYSBENCH_WORKLOAD} --mysql-db=clustrix_perf --db-driver=mysql --mysql-host=localhost --mysql-port=${DBPORT} --mysql-user=${DBUSER} --mysql-password=${DBPASSWORD} --max-requests=0 --time=${DURATION} --report-interval=1 --table-size=${TABLE_SIZE} --rand-type=uniform --threads=${THREADS} run"
                
                echo ""
                echo "        THREADS : ${THREADS}"
                echo "        COMMAND : ${COMMAND}"
                
                for NODE in ${CLUSTER_NODES[*]} ; do
                    ssh ${USERID}@${NODE} ${SSH_OPTIONS} "${COMMAND}" > ${WORKDIRECTORY}/log/$(date +%y%m%d.%H%M).${NODE}.sysbench.${SYSBENCH_TEST}.test.${THREADS}.log 2>&1 &
                done
                wait
                
                for NODE in ${CLUSTER_NODES[*]} ; do
                    cat ${WORKDIRECTORY}/log/*.${NODE}.sysbench.${SYSBENCH_TEST}.test.${THREADS}.log | sed 's/ms$//g;s/s$//g;' | awk '
                    /^Number of threads: / { threads = $4 }
                    /^    total time: / { totaltime = $3 }
                    /^    total number of events: / { operations = $5 }
                    /^         avg: / { latency_avg = $2 }
                    /^         95th percentile: / { latency_95 = $3; ops = operations / totaltime;
                    printf "%i\t%.2f\t%.3f\t%.3f\n" , threads, ops, latency_avg, latency_95 }
                    ' >> ${WORKDIRECTORY}/${NODE}.sysbench.${SYSBENCH_TEST}.data.txt
                done
                
                CURRENT_LATENCY=$(tail -n1 -q  ${WORKDIRECTORY}/*.sysbench.${SYSBENCH_TEST}.data.txt | awk '
                { drivers = drivers + 1;  total_latency = total_latency + $3;}
                END { printf "%.3f", total_latency / drivers }
                ')
                echo "        THREADS : ${THREADS}, MAX_THREADS : ${MAX_THREADS}, CURRENT_LATENCY : ${CURRENT_LATENCY},  TARGETLATENCY : ${TARGETLATENCY}"
                if [[ ${GROWTH} == linear ]] ; then
                    (( THREADS = ${BASEVALUE} * ${N} ))
                elif [[ ${GROWTH} == exponential ]] ; then
                    (( THREADS = ${BASEVALUE} ** ${N} ))
                elif [[ ${GROWTH} == quadratic ]] ; then
                    (( THREADS = ${N} ** ${BASEVALUE} ))
                fi
                (( N = ${N} + 1 ))
                if (( $(echo "${CURRENT_LATENCY} 0" | awk '{print ($1 == $2)}') )) ; then
                    CURRENT_LATENCY=TARGETLATENCY
                fi
            
            done
        
        } 2>&1 | tee ${WORKDIRECTORY}/log/$(date +%y%m%d.%H%M).test.${SYSBENCH_TEST}.log
        
        echo ""
        echo "        ===== Test Data =====  [ $(date -u '+%Y-%m-%d %H:%M:%S') ]"
        for NODE in ${CLUSTER_NODES[*]} ; do
            echo ""
            echo "Node : ${NODE}"
            cat ${WORKDIRECTORY}/${NODE}.sysbench.${SYSBENCH_TEST}.data.txt
        done
        
        {
            echo "set datafile separator '\t'"
            echo "set terminal png size 960,480 enhanced font '/usr/share/fonts/liberation/LiberationSans-Regular.ttf' 11 linewidth 2"
            echo "set yrange [0:${TARGETLATENCY}] "
            echo "set xrange [0:]"
            echo "set ylabel 'Avg Latency (ms)'"
            echo "set xlabel 'Throughput'"
            echo "set output '${WORKDIRECTORY}/power.sysbench.${SYSBENCH_TEST}.png'"
            echo "set title 'Sysbench ${SYSBENCH_TEST}'"
            INDX=0;
            for FILE in ${WORKDIRECTORY}/*.sysbench.${SYSBENCH_TEST}.data.txt ; do
                NODE=$(echo $FILE | sed 's\.sysbench.${SYSBENCH_TEST}.data.txt\\g' | awk -F/ '{ print $NF }')
                INDX=$(( $INDX + 1 ))
                if (( $INDX == 1 )) ; then
                    echo "plot  '${FILE}' using 2:3 title '${NODE}' with lines \\"
                else
                    echo ", '${FILE}' using 2:3 title '${NODE}' with lines \\"
                fi
            done
            echo ""
            echo "exit"
        } | gnuplot > ${WORKDIRECTORY}/log/gnuplot.${SYSBENCH_TEST}.log 2>&1
        
        {
            cat $(ls -1 ${WORKDIRECTORY}/*.sysbench.${SYSBENCH_TEST}.data.txt | head -1) | head -1
            for THREADS in $(cat $(ls -1 ${WORKDIRECTORY}/*.sysbench.${SYSBENCH_TEST}.data.txt | head -1) | cut -f1 | grep -v thread) ; do
                cat ${WORKDIRECTORY}/*.sysbench.${SYSBENCH_TEST}.data.txt | grep "^${THREADS}"$'\t' | awk '
                    { cnt = cnt + 1; threads = threads + $1; throughput = throughput + $2; latency = latency + $3; ninety = ninety + $4 }
                    END { printf "%.0f\t%.2f\t%.2f\t%.2f\n", threads, throughput, latency / cnt, ninety / cnt }
                    '
            done
        } > ${WORKDIRECTORY}/sysbench.${SYSBENCH_TEST}.data.txt
        echo ""
        echo "    Aggregate Results :"
        cat ${WORKDIRECTORY}/sysbench.${SYSBENCH_TEST}.data.txt
 
        POWER_RATING=$(cat ${WORKDIRECTORY}/sysbench.${SYSBENCH_TEST}.data.txt | (read; cat) | cut -f2 | awk 'BEGIN { max = 0 }; {  if ($1 > max) { max = $1 } }; END { print max }')
    
            echo ""
        echo "    DB ${SYSBENCH_TEST} Power Rating : ${POWER_RATING}"
            
            echo "${POWER_RATING}" > ${WORKDIRECTORY}/db.${SYSBENCH_TEST}.power.rating.txt
            
    done

    {
        echo '<html>'
        echo '<body>'
        echo '<h1>Cluster Sysbench DB Tests</h1>'
        echo "<h3>Cluster Name: ${CLUSTER_NAME}</h3>"
        echo "<h3>Cluster Nodes: ${CLUSTER_NODES[*]}</h3>"
        echo '<h2>Test Results</h2>'
        echo '<h3>Sysbench Reads:</h3>'
        echo "<h4>DB Read Power Rating: $(cat ${WORKDIRECTORY}/db.reads.power.rating.txt)</h4>"
        echo "<h3>Per Node Balance:</h3>"
        echo '<img src="power.sysbench.reads.png" />'
        echo '<h3>Sysbench 9010:</h3>'
        echo "<h4>DB OLTP Power Rating: $(cat ${WORKDIRECTORY}/db.9010.power.rating.txt)</h4>"
        echo "<h3>Per Node Balance:</h3>"
        echo '<img src="power.sysbench.9010.png" />'
        echo '<h3>Sysbench Writes:</h3>'
        echo "<h4>DB Write Power Rating: $(cat ${WORKDIRECTORY}/db.writes.power.rating.txt)</h4>"
        echo "<h3>Per Node Balance:</h3>"
        echo '<img src="power.sysbench.writes.png" />'
        echo '<h2>Test Data</h2>'
        echo '<h3>Sysbench Reads:</h3>'
        for NODE in ${CLUSTER_NODES[*]}; do
            echo "<h3>Node: ${NODE}</h3>"
            echo '<pre>'
            cat ${WORKDIRECTORY}/${NODE}.sysbench.reads.data.txt
            echo '</pre>'
        done
        echo '<h3>Sysbench 9010:</h3>'
        for NODE in ${CLUSTER_NODES[*]}; do
            echo "<h3>Node: ${NODE}</h3>"
            echo '<pre>'
            cat ${WORKDIRECTORY}/${NODE}.sysbench.9010.data.txt
            echo '</pre>'
        done
        echo '<h3>Sysbench Writes:</h3>'
        for NODE in ${CLUSTER_NODES[*]}; do
            echo "<h3>Node: ${NODE}</h3>"
            echo '<pre>'
            cat ${WORKDIRECTORY}/${NODE}.sysbench.writes.data.txt
            echo '</pre>'
        done
        echo '<h2>Test Files</h2>'
        for FILE in $(ls -1 ${WORKDIRECTORY}/ | awk -F'/' '{print $(NF)}' ) ; do
            echo $FILE |  awk '{ printf "<h4><a href=\"%s\">%s</a></h4>\n", $1, $1 ; }'
        done
    } > ${WORKDIRECTORY}/index.html
    
    echo ""
    echo "    ===== Test complete =====  [ $(date -u '+%Y-%m-%d %H:%M:%S') ]"
    echo ""
    if [[ ${OPTION_COMPRESS} == TRUE ]] ; then
        echo "        Results File : ${WORKDIRECTORY}.tgz"
        echo ""
    fi
    echo "    ===== End clxperf.sysbench.db.test.sh ( Elapsed Seconds = $(( $SECONDS - $STARTSECONDS )) ) =====  [ $(date -u '+%Y-%m-%d %H:%M:%S') ]"
    echo ""
    
} 2>&1 | tee ${WORKDIRECTORY}/log/clxperf.sysbench.db.test.log

# zip it all up
if [[ ${OPTION_COMPRESS} == TRUE ]] ; then
    if [[ ${LOGDIRECTORY} ]] ; then
        cd ${LOGDIRECTORY}; tar czf ${WORKDIRECTORY}.tgz ${TESTID}*/
    else
        tar czf ${WORKDIRECTORY}.tgz ${TESTID}*/
    fi
fi
