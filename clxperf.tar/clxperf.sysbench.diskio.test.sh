#!/bin/bash

#############

USAGE="usage: $0

Usage:
    Performs a smoke test of the disk subsystem of a cluster.  The test produces graphical
    results which demonstate balance across the cluster.  A healthly cluster would produce similar
    performance curves for each node in the cluster.
    
Optional Arguments:
    host, --host              host name of a node of the cluster (default: localhost)
    user, --user              host user (default: current userid)
    port, --port              host port number
    pem, --pem                pem file 
        
    dbuser, --dbuser          database user name (default: root)
    dbport, --dbport          mysql port number (default: 3306)
    dbpassword, --dbpassword  database user password
    
    duration, --duration      length of each test point in seconds (default: 10)
    datasize, --dataszie      data size for io test (default: 10G)
    maxthreads, --maxthreads  maximum number of threads to run (default: 1024)
    
    growth, --growth          method of growth in threads (default: linear)
                                valid values: linear (base*n), exponential (base^n), quadratic (n^base)
    basevalue, --basevalue    base value in growth (default: 2)
    
    targetlatency             target latency (ms) to terminate performance curve (default: 2.0)    
    
    nocompress                disable compression of result directory

    help, --help              show usage message and exits
     
Notes:
1.  The script can be run either 'on-platform' or 'off-platform' depending on connectivity and 
access to the cluster.

Here are some options.

1a.  Use a pem file.
     (This method assumes that the userid can access all nodes in the cluster using the pem file.)

    ./clxperf.sysbench.diskio.test.sh --host node --user userid --pem ~/.ssh/somepemfile.pem

1d.  Execute the script from a remote node, providing connection info to the cluster.
     (This method assumes that user has passwordless ssh access to all nodes in the cluster.)

    ./clxperf.sysbench.diskio.test.sh --host node --user userid

1c.  Copy the script onto a node in the cluster, execute the script on that node, then copy the
     results off.
     (This method assumes the userid can do remote logins from the host node to all the other
     nodes in the cluster.)
     
     scp clxperf.sysbench.cpu.test.sh userid@node:.
     ssh userid@node './clxperf.sysbench.diskio.test.sh'
     scp userid@node:*.clxperf.*.tgz .
     ssh userid@node 'rm -rf *.clxperf.*'

1d.  Pipe the script through an ssh logon to a node in the cluster.  The results will be on
     the cluster node an will need to be copied off.

    ssh userid@node < clxperf.sysbench.diskio.test.sh
    scp userid@node:*.clxperf.*.tgz .
    ssh userid@node 'rm -rf *.clxperf.*'

2.  The script will install sysbench, gnuplot, and liberation-sans-fonts on each node of 
the cluster.
"

while [[ $# > 0 ]] ; do
    key="$1"; shift;
    case ${key} in
        host|--host)              HOST="$1"; shift;;
        user|--user)              USERID="$1"; shift;;
        password|--password)      PASSWORD="$1"; shift;;
        port|--port)              PORT="$1"; shift;;
        pem|--pem)                PEM="$1"; shift;;
        dbuser|--dbuser)          DBUSER="$1"; shift;;
        dbport|--dbport)          DBPORT="$1"; shift;;
        dbpassword|--dbpassword)  DBPASSWORD="$1"; shift;;
        duration|--duration)      DURATION="$1"; shift;;
        datasize|--datasize)      DATA_SIZE="$1"; shift;;
        maxthreads|--maxthreads)  MAX_THREADS="$1"; shift;;
        growth|--growth)          GROWTH="$1"; shift;;
        basevalue|--basevalue)    BASEVALUE="$1"; shift;;
        targetlatency)            TARGETLATENCY="$1"; shift;;
        nocompress)               OPTION_COMPRESS=FALSE;;
        help|--help)              echo -e "$USAGE"; exit 1;;
        *)                        echo "Invalid option specified : $key"; echo -e "$USAGE"; exit 1;;
    esac
done

# Defaults
if [[ ! ${HOST} ]] ;            then HOST=localhost;       fi
if [[ ! ${USERID} ]] ;          then USERID=$(whoami);     fi
if [[ ! ${DBUSER} ]] ;          then DBUSER=root;          fi
if [[ ! ${DBPORT} ]] ;          then DBPORT=3306;          fi
if [[ ! ${DURATION} ]] ;        then DURATION=10;          fi
if [[ ! ${DATA_SIZE} ]] ;       then DATA_SIZE=10G;        fi
if [[ ! ${MAX_THREADS} ]] ;     then MAX_THREADS=1024;     fi
if [[ ! ${OPTION_COMPRESS} ]] ; then OPTION_COMPRESS=TRUE; fi

if [[ ${PORT} ]] ; then
    PORT_OPTION="-p${PORT}"
fi
if [[ ${PEM} ]] ; then
    PEM_OPTION="-i${PEM}"
fi
SSH_OPTIONS="-oStrictHostKeyChecking=no ${SSH_PORT_OPTION} ${PEM_OPTION}"

if [[ ${DBUSER} ]] ; then
    DBUSER_OPTION="--user=${DBUSER}"
fi
if [[ ${DBPORT} ]] ; then
    DBPORT_OPTION="--port=${DBPORT}"
fi
if [[ ${DBPASSWORD} ]] ; then
    DBPASSWORD_OPTION="--password=${DBPASSWORD}"
fi
MYSQL_OPTIONS="${DBUSER_OPTION} ${DBPORT_OPTION} ${DBPASSWORD_OPTION}"

if [[ ! ${GROWTH} ]] ; then
    GROWTH=quadratic
fi

if [[ ! ${BASEVALUE} ]] ; then
    BASEVALUE=2
fi

if [[ ${GROWTH} != linear && ${GROWTH} != exponential && ${GROWTH} != quadratic  ]] ; then
    echo "Invalid growth option specified : ${GROWTH}"; echo -e "$USAGE"; exit 1;
fi

if [[ ! ${TARGETLATENCY} ]] ; then
    TARGETLATENCY=5.0
fi

#############

# get the cluster name
COMMAND="mysql -sN ${MYSQL_OPTIONS} -e\"show variables like 'cluster_name'\""
CLUSTER_NAME=$( ssh ${USERID}@${HOST} ${SSH_OPTIONS} "${COMMAND}" | awk '{print $2}' )

# create a new work directory
TESTID=$(date +%y%m%d.%H%M%S).${CLUSTER_NAME}
if [[ ${LOGDIRECTORY} ]] ; then
    WORKDIRECTORY=${LOGDIRECTORY}/${TESTID}.clxperf.sysbench.diskio.test
else
    WORKDIRECTORY=${TESTID}.clxperf.sysbench.diskio.test
fi
mkdir -p ${WORKDIRECTORY}
mkdir -p ${WORKDIRECTORY}/log

{
    echo ""
    echo "    ===== Begin clxperf.sysbench.diskio.test.sh =====  [ $(date -u '+%Y-%m-%d %H:%M:%S') ]"
    
    STARTSECONDS=$SECONDS
    
    echo ""
    echo "        Cluster Name : $CLUSTER_NAME"
    
    # Determine the nodes
    COMMAND="mysql -sN ${MYSQL_OPTIONS} -e\"select iface_ip from system.nodeinfo order by 1\""
    CLUSTER_NODES=$( ssh ${USERID}@${HOST} ${SSH_OPTIONS} "${COMMAND}" | awk '{printf "%s ", $1}')
    echo ""
    echo "        Cluster Nodes : ${CLUSTER_NODES[*]}"
    
    # Install latest version of sysbench 1.0 on each node
    echo ""
    echo "    ===== Node Setup : Installing sysbench =====  [ $(date -u '+%Y-%m-%d %H:%M:%S') ]"
    time {
        for NODE in ${CLUSTER_NODES[*]} ; do
            {
                echo "Node : ${NODE}"
                ssh ${USERID}@${NODE} ${SSH_OPTIONS} 'sudo curl -s https://packagecloud.io/install/repositories/akopytov/sysbench/script.rpm.sh | sudo bash'
                ssh ${USERID}@${NODE} ${SSH_OPTIONS} 'sudo yum -y install sysbench; sudo yum -y install gnuplot; sudo yum -y install liberation-sans-fonts;'
                ssh ${USERID}@${NODE} ${SSH_OPTIONS} 'sysbench --version'
            } > ${WORKDIRECTORY}/log/${NODE}.setup.log 2>&1 &
        done
        wait
    }
    
    echo ""
    echo "    ===== Prepare Nodes - Load Data =====  [ $(date -u '+%Y-%m-%d %H:%M:%S') ]"
    time {
        for NODE in ${CLUSTER_NODES[*]} ; do
            {
                echo "        Node : ${NODE}"
                ssh ${USERID}@${NODE} ${SSH_OPTIONS} "sudo mkdir -p /data/clustrix/sbtest; sudo chmod 777 /data/clustrix/sbtest; cd /data/clustrix/sbtest; sysbench fileio --file-total-size=${DATA_SIZE} prepare; ls -l;"
            } > ${WORKDIRECTORY}/log/${NODE}.prepare.log 2>&1 &
        done
        wait
    }
    
    echo ""
    echo "    ===== Disk IO Test =====  [ $(date -u '+%Y-%m-%d %H:%M:%S') ]"
    time {
        
            for BLK_SIZE in 512 4k 32k ; do 
                                
            echo ""
            echo "        Block Size : ${BLK_SIZE}  [ $(date -u '+%Y-%m-%d %H:%M:%S') ]"

            for NODE in ${CLUSTER_NODES[*]} ; do
                echo -e 'threads''\t''ops''\t''avg_latency''\t''95_percentile' > ${WORKDIRECTORY}/${NODE}.${BLK_SIZE}.sysbench.diskio.data.txt
            done
            
            CURRENT_LATENCY=0.0; THREADS=1; N=1;
            
            while (( $(echo "${CURRENT_LATENCY} ${TARGETLATENCY}" | awk '{print ($1 < $2)}') && (( $THREADS <= ${MAX_THREADS} )) )); do
                COMMAND="
                cd /data/clustrix/sbtest; pwd; ls -l;
                sysbench fileio --threads=${THREADS} --time=${DURATION} --file-block-size=${BLK_SIZE} --file-total-size=${DATA_SIZE} --file-test-mode=rndrw run"
                echo ""
                echo "        THREADS : ${THREADS}"
                echo "        COMMAND : ${COMMAND}"
                for NODE in ${CLUSTER_NODES[*]} ; do
                    ssh ${USERID}@${NODE} ${SSH_OPTIONS} "${COMMAND}" > ${WORKDIRECTORY}/log/$(date +%y%m%d.%H%M).${NODE}.${BLK_SIZE}.sysbench.diskio.test.${THREADS}.log 2>&1 &
                done
                wait
                for NODE in ${CLUSTER_NODES[*]} ; do
                    cat ${WORKDIRECTORY}/log/*.${NODE}.${BLK_SIZE}.sysbench.diskio.test.${THREADS}.log | sed 's/ms$//g;s/s$//g;' | awk '
                        /^Number of threads: / { threads = $4 }
                        /^    total time: / { totaltime = $3 }
                        /^    total number of events: / { operations = $5 }
                        /^         avg: / { latency_avg = $2 }
                        /^         95th percentile: / { latency_95 = $3; ops = operations / totaltime;
                        printf "%i\t%.2f\t%.3f\t%.3f\n" , threads, ops, latency_avg, latency_95 }
                        ' >> ${WORKDIRECTORY}/${NODE}.${BLK_SIZE}.sysbench.diskio.data.txt
                done
                CURRENT_LATENCY=$(tail -n1 -q  ${WORKDIRECTORY}/*.${BLK_SIZE}.sysbench.diskio.data.txt | awk '
                    { drivers = drivers + 1;  total_latency = total_latency + $3;}
                    END { printf "%.3f", total_latency / drivers }
                    ')
                echo "        THREADS : ${THREADS}, CURRENT_LATENCY : ${CURRENT_LATENCY},  TARGETLATENCY : ${TARGETLATENCY}"
                if [[ ${GROWTH} == linear ]] ; then
                    (( THREADS = ${BASEVALUE} * ${N} ))
                elif [[ ${GROWTH} == exponential ]] ; then
                    (( THREADS = ${BASEVALUE} ** ${N} ))
                elif [[ ${GROWTH} == quadratic ]] ; then
                    (( THREADS = ${N} ** ${BASEVALUE} ))
                fi
                (( N = ${N} + 1 ))
                if (( $(echo "${CURRENT_LATENCY} 0" | awk '{print ($1 == $2)}') )) ; then
                    CURRENT_LATENCY=TARGETLATENCY
            fi
            done
            
            echo ""
            echo "        Test Data :  [ $(date -u '+%Y-%m-%d %H:%M:%S') ]"
            for NODE in ${CLUSTER_NODES[*]} ; do
                echo ""
                echo "Node : ${NODE}"
                cat ${WORKDIRECTORY}/${NODE}.${BLK_SIZE}.sysbench.diskio.data.txt
            done
    
            {
                echo "set datafile separator '\t'"
                echo "set terminal png size 960,480 enhanced font '/usr/share/fonts/liberation/LiberationSans-Regular.ttf' 11 linewidth 2"
                echo "set yrange [0:${TARGETLATENCY}] "
                echo "set xrange [0:]"
                echo "set ylabel 'Avg Latency (ms)'"
                echo "set xlabel 'Throughput'"
                echo "set output '${WORKDIRECTORY}/power.${BLK_SIZE}.sysbench.diskio.png'"
                echo "set title 'Sysbench DiskIO - Block Size ${BLK_SIZE}'"
                INDX=0;
                for FILE in ${WORKDIRECTORY}/*.${BLK_SIZE}.sysbench.diskio.data.txt ; do
                    NODE=$(echo $FILE | sed 's\.sysbench.diskio.data.txt\\g' | awk -F/ '{ print $NF }')
                    INDX=$(( $INDX + 1 ))
                    if (( $INDX == 1 )) ; then
                        echo "plot  '${FILE}' using 2:3 title '${NODE}' with lines \\"
                    else
                        echo ", '${FILE}' using 2:3 title '${NODE}' with lines \\"
                    fi
                done
                echo ""
                echo "exit"
            } | gnuplot > ${WORKDIRECTORY}/log/gnuplot.${BLK_SIZE}.log 2>&1

            {
                cat $(ls -1 ${WORKDIRECTORY}/*.${BLK_SIZE}.sysbench.diskio.data.txt | head -1) | head -1
                for THREADS in $(cat $(ls -1 ${WORKDIRECTORY}/*.${BLK_SIZE}.sysbench.diskio.data.txt | head -1) | cut -f1 | grep -v thread) ; do
                    cat ${WORKDIRECTORY}/*.${BLK_SIZE}.sysbench.diskio.data.txt | grep "^${THREADS}"$'\t' | awk '
                        { cnt = cnt + 1; threads = threads + $1; throughput = throughput + $2; latency = latency + $3; ninety = ninety + $4 }
                        END { printf "%.0f\t%.2f\t%.2f\t%.2f\n", threads, throughput, latency / cnt, ninety / cnt }
                        '
                done
            } > ${WORKDIRECTORY}/sysbench.${BLK_SIZE}.diskio.data.txt
            echo ""
            echo "Aggregate Results :"
            cat ${WORKDIRECTORY}/sysbench.${BLK_SIZE}.diskio.data.txt

                POWER_RATING=$(cat ${WORKDIRECTORY}/sysbench.${BLK_SIZE}.diskio.data.txt | (read; cat) | cut -f2 | awk 'BEGIN { max = 0 }; {  if ($1 > max) { max = $1 } }; END { print max }')

                echo "${POWER_RATING}" > ${WORKDIRECTORY}/diskio.${BLK_SIZE}.power.rating.txt

            echo ""
            echo "    Disk IO ${BLK_SIZE} Power Rating : ${POWER_RATING}"
            
        done
    } 2>&1 | tee ${WORKDIRECTORY}/log/$(date +%y%m%d.%H%M).run.test.log
    
    echo ""
    echo "    ===== Node Cleanup - Delete Data =====  [ $(date -u '+%Y-%m-%d %H:%M:%S') ]"
    time {
        for NODE in ${CLUSTER_NODES[*]} ; do
        {
            echo "Node : ${NODE}"
            ssh ${USERID}@${NODE} ${SSH_OPTIONS} "sudo rm -rf /data/clustrix/sbtest"
        } > ${WORKDIRECTORY}/log/${NODE}.cleanup.log 2>&1 &
        done
        wait
    }
    

    {
        echo '<html>'
        echo '<body>'
        echo '<h1>Cluster Sysbench Random RW DiskIO Test</h1>'
        echo "<h3>Cluster Name: ${CLUSTER_NAME}</h3>"
        echo "<h3>Cluster Nodes: ${CLUSTER_NODES[*]}</h3>"
        echo '<h2>Test Results</h2>'
            for BLK_SIZE in 512 4k 32k ; do 
            echo "<h3>Block Size: ${BLK_SIZE}</h3>"
            echo "<h4>Disk IO Power Rating: $(cat ${WORKDIRECTORY}/diskio.${BLK_SIZE}.power.rating.txt)</h4>"
            echo "<h4>Per Node Balance:</h4>"
            echo "<img src='power.${BLK_SIZE}.sysbench.diskio.png' />"
        done
        echo '<h2>Test Files</h2>'
        for FILE in $(ls -1 ${WORKDIRECTORY}/ | awk -F'/' '{print $(NF)}' ) ; do
            echo $FILE |  awk '{ printf "<h4><a href=\"%s\">%s</a></h4>\n", $1, $1 ; }'
        done
    } > ${WORKDIRECTORY}/index.html
    
    echo ""
    echo "    ===== Test complete =====  [ $(date -u '+%Y-%m-%d %H:%M:%S') ]"
    echo ""
    if [[ ${OPTION_COMPRESS} == TRUE ]] ; then
        echo "        Results File : ${WORKDIRECTORY}.tgz"
        echo ""
    fi
    echo "    ===== End clxperf.sysbench.diskio.test.sh ( Elapsed Seconds = $(( $SECONDS - $STARTSECONDS )) ) =====  [ $(date -u '+%Y-%m-%d %H:%M:%S') ]"
    echo ""
    
} 2>&1 | tee ${WORKDIRECTORY}/log/clxperf.sysbench.diskio.test.log

# zip it all up
if [[ ${OPTION_COMPRESS} == TRUE ]] ; then
    if [[ ${LOGDIRECTORY} ]] ; then
        cd ${LOGDIRECTORY}; tar czf ${WORKDIRECTORY}.tgz ${TESTID}*/
    else
        tar czf ${WORKDIRECTORY}.tgz ${TESTID}*/
    fi
fi
